<?php 
require_once 'models/Model.php';


class OrderDetails extends Model {

    public function __construct()
    {
        parent::__construct('order_details');

    }

}

?>




