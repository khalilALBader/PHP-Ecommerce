<?php

require_once __DIR__."/helpers/functions.php";
require_once __DIR__ . '/config/Router.php';
require_once __DIR__ . "/routes/web.php";
session_start();

// require_once __DIR__ . "/views/public/pages/home.view.php";



?>