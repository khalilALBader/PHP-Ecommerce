<?php require_once "views\layout\admin\sidebar.php"; ?>



</html>
<script src="<?= asset('/dist/script.js') ?>"></script>