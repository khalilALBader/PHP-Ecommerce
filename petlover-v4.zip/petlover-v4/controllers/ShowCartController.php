<?php

class ShowCartController
{
    public function index()
    {
        require_once 'views\public\cart\show-cart.view.php';
    }
}