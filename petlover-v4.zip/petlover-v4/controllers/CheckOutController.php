<?php

class CheckOutController
{
    public function index()
    {
        require_once 'views\public\cart\checkout.view.php';
    }
}