<?php

class ServiceController
{
    public function index()
    {
        require_once 'views\public\pages\service.view.php';
    }
}