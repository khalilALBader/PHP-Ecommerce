<?php

class AdminSingInController
{
    public function index()
    {
        require_once 'views\admin\auth\sign_in.view.php';
    }
}